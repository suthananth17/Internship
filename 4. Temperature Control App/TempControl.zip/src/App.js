import TempControl from "./Components/TempControl";

function App() {
  return (
    <div>
      <TempControl />
    </div>
  );
}

export default App;
