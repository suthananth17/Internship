export const roles = {
    STUDENT: 'Student',
    SUPERVISOR: 'Supervisor',
    PANEL_MEMBER: 'PanelMember',
    ADMIN: 'Admin',
    GROUP_LEADER: 'ChatGroupLeader'
}