import { NavLink } from "react-router-dom";
import "./Header.css";

const Header = () => {
  return (
    <div>
      <ul className="header">
        <li  className="inline">
          <NavLink  className="inlineFont" to="/home">
            Home
          </NavLink>
        </li>
        <li className="inline">
          <NavLink className="inlineFont" to="/viewposts">
            View Posts
          </NavLink>
        </li>
        <li className="end inline">
          <NavLink className="inlineFont end" to="/createnewpost">
            Create New
          </NavLink>
        </li>
      </ul>
    </div> 
  );
};

export default Header;
