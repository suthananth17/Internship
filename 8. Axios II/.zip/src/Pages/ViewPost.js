import Card from "../Components/UI/Card";

function ViewPost(props) {
  return (
    <div>
      <Card key={props.id} >
        <p className="blog">Blog: {props.id}</p><br></br>
        <p className="title">{props.title}</p><br></br>
        <p className="description">{props.body}</p>
        
      </Card>
    </div>
  );
}

export default ViewPost;
