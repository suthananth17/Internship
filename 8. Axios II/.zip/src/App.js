import { Route } from "react-router-dom";
import { useState, useEffect } from "react";
import api from "./api/Axios";
import Header from "./Components/navBar/Header";
import CreateNewPost from "./Pages/CreateNewPost";
import ViewPost from "./Pages/ViewPost";
import "../src/index.css";
import "./App.css";

function App() {
  const [posts, setPosts] = useState([""]);

  //Fetch Pots
  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const response = await api.get("/Posts");
        setPosts(response.data);
      } catch (err) {
        if (err.response) {
          // Not in the 200 response range
          console.log(err.response.data);
          console.log(err.response.status);
          console.log(err.response.headers);
        } else {
          console.log(`Error: ${err.message}`);
        }
      }
    };
    fetchPosts();
  }, []);


  //Post Posts

  //getting data from new post
  const onSavePostDataHandler = async (enteredPostData) => {
    const postData = {
      ...enteredPostData,
      id: Math.random().toString(),
    };
    const newPost = postData;
    try {
      const response = await api.post("/posts", newPost);
      const allPosts = [...posts, response.data];
      setPosts(allPosts);
    } catch (err) {
      console.log(`Error: ${err.message}`);
    }
  };

  return (
    <div>
      <Header />
      <Route path="/viewposts">
        <div className="container">
          {posts.map((post) => {
            return (
              <ViewPost
                id={post.id}
                title={post.title}
                body={post.body}
              />
            );
          })}
        </div>
      </Route>
      <Route path="/createnewpost"> <CreateNewPost onSavePostData={onSavePostDataHandler} /> </Route>
    </div>
  );
}

export default App;
