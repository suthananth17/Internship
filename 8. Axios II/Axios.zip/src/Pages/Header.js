import { Link } from "react-router-dom";
import './Header.css';

const Header = () => {
  return (
    <div className="container">
      <ul className="header"> 
        <li>
          <Link className="inlineFont" to="/">Home</Link>
        </li>
        <li>
          <Link className="inlineFont" to="/viewposts">View Posts</Link>
        </li>
      </ul>
    </div>
  );
};

export default Header;
