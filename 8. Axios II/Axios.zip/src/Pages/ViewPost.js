import { useState } from "react";
import Crud from "./Crud";


function ViewPost() {
 
  const [post, setPost] = useState();
  
  const onPostHandler = (viewPosts) => {
    setPost(viewPosts);
    console.log(post);
  
  };

  return (
    <div>
      <Crud onPotseHandler={onPostHandler} />
      {post.map((post) => {
        return (
          <article className="post">
            <h2>ID: {post.id}</h2>
            <h2>Title: {post.title}</h2>
            <p className="postBody">Desciption:{post.body}</p>
            <br></br>
          </article>
        );
      })}
     
    </div>
  );
}

export default ViewPost;
