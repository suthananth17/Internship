import "../src/index.css";
import ViewPost from "./Pages/ViewPost";
import { Route } from "react-router-dom";
import Header from "./Pages/Header";

function App() {
  return (
    <div>

        <Route path="/viewposts">
          <ViewPost />
        </Route>

        <Header/>

      
    </div>
  );
}

export default App;
